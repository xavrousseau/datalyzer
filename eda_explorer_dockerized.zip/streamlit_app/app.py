import streamlit as st
import pandas as pd
import requests
import plotly.express as px
from streamlit_app.eda_utils import (
    detect_variable_types,
    compute_correlation_matrix,
    detect_outliers_iqr,
    detect_constant_columns,
    detect_low_variance_columns,
    encode_categorical
)

API_URL = "http://localhost:8000"
st.set_page_config(page_title="EDA Explorer", layout="wide")
st.title("📊 EDA Explorer – Application d'analyse exploratoire de données")

# === 1. UPLOAD DE FICHIER ===
st.header("1. Charger un fichier CSV")
uploaded_file = st.file_uploader("Choisir un fichier", type=["csv"])
df = None

if uploaded_file:
    response = requests.post(
        f"{API_URL}/upload/", 
        files={"file": (uploaded_file.name, uploaded_file, "text/csv")}
    )
    if response.status_code == 200:
        meta = response.json()
        st.success("Fichier chargé avec succès.")
        st.write("**Colonnes :**", meta["columns"])
        st.write("**Nombre de lignes :**", meta["rows"])
        head = requests.get(f"{API_URL}/head?n=500").json()
        df = pd.DataFrame(head) if isinstance(head, list) and head else None
    else:
        st.error(f"Erreur : {response.json().get('error')}")

# === 2. SECTION : EDA GÉNÉRALE (SANS CIBLE) ===
if df is not None:
    st.header("2. Analyse exploratoire générale (sans cible)")

    with st.expander("📌 Types de variables détectées", expanded=False):
        st.info("Détection automatique des types : numérique, catégorielle, binaire, texte libre.")
        st.dataframe(detect_variable_types(df))

    with st.expander("📈 Distributions des variables numériques", expanded=False):
        st.info("Histogrammes des variables numériques (sélectionnez une variable).")
        num_cols = df.select_dtypes(include=["number"]).columns.tolist()
        col = st.selectbox("Sélectionner une variable", num_cols)
        st.plotly_chart(px.histogram(df, x=col), use_container_width=True)

    with st.expander("🚨 Analyse des outliers (IQR)", expanded=False):
        st.info("Détecte les valeurs extrêmes selon la méthode IQR.")
        col = st.selectbox("Choisir une variable numérique", num_cols, key="iqr_col")
        outliers = detect_outliers_iqr(df, col)
        st.write(f"{len(outliers)} outliers détectés.")
        st.dataframe(outliers)

    with st.expander("🧹 Suggestions de nettoyage", expanded=False):
        st.info("Détecte les colonnes constantes, à faible variance, ou très manquantes.")
        st.write("Colonnes constantes :", detect_constant_columns(df))
        st.write("Colonnes faible variance :", detect_low_variance_columns(df))
        missing = df.isnull().mean().sort_values(ascending=False)
        st.write("Valeurs manquantes :", missing[missing > 0])

    with st.expander("🧼 Nettoyage manuel (doublons / colonnes)", expanded=False):
        if st.button("Supprimer les doublons"):
            res = requests.post(f"{API_URL}/drop-duplicates/").json()
            st.success(f"{res['removed']} doublons supprimés.")

        cols_to_drop = st.multiselect("Colonnes à supprimer", df.columns.tolist())
        if cols_to_drop and st.button("Supprimer les colonnes sélectionnées"):
            res = requests.post(f"{API_URL}/drop-columns/", json={"columns": cols_to_drop})
            st.success(res.json()["message"])

# === 3. SECTION : ANALYSE ORIENTÉE CIBLE ===
    st.header("3. Analyse orientée variable cible")
    st.markdown("Définissez ci-dessous une ou deux variables cibles pour guider l’analyse.")

    target_1 = st.selectbox("🎯 Variable cible principale", df.select_dtypes(include=["number"]).columns.tolist(), key="target1")
    target_2 = st.selectbox("🎯 Variable cible secondaire (facultative)", [None] + df.select_dtypes(include=["number"]).columns.tolist(), key="target2")

    with st.expander("📊 Corrélations avec la variable cible", expanded=False):
        st.info("Affiche les variables numériques les plus corrélées à la cible sélectionnée.")
        corr = df.select_dtypes(include=["number"]).corr()[target_1].drop(target_1).sort_values(ascending=False)
        st.dataframe(corr)
        st.plotly_chart(px.bar(corr.reset_index(), x="index", y=target_1, title="Corrélations avec la cible"), use_container_width=True)

    with st.expander("📈 Graphiques exploratoires métiers", expanded=False):
        cat_cols = df.select_dtypes(include=["object", "category"]).columns.tolist()
        group_col = st.selectbox("Variable catégorielle pour les graphiques métiers", cat_cols, key="groupcol")
            st.info("Affiche des bar charts par type de bâtiment (si applicable).")
            avg_target1 = df.groupby(group_col)[target_1].mean().sort_values(ascending=False).reset_index()
            st.plotly_chart(px.bar(avg_target1, x="building_type", y=target_1, title=f"{target_1} moyen par type de bâtiment"), use_container_width=True)

            if target_2:
                avg_target2 = df.groupby(group_col)[target_2].mean().sort_values(ascending=False).reset_index()
                st.plotly_chart(px.bar(avg_target2, x="building_type", y=target_2, title=f"{target_2} moyen par type de bâtiment"), use_container_width=True)

    with st.expander("🔄 Encodage des variables catégorielles", expanded=False):
        st.info("Transforme les colonnes catégorielles en variables numériques via OneHot ou Ordinal.")
        cat_cols = df.select_dtypes(include=["object", "category"]).columns.tolist()
        selected = st.multiselect("Colonnes à encoder", cat_cols)
        method = st.radio("Méthode", ["onehot", "ordinal"])
        if st.button("Encoder"):
            df_encoded = encode_categorical(df.copy(), method=method, columns=selected)
            st.dataframe(df_encoded.head())


    with st.expander("📦 Boxplot interactif", expanded=False):
        st.info("Permet de visualiser la dispersion d'une variable numérique selon une catégorie.")
        cat_col = st.selectbox("Variable catégorielle (X)", df.select_dtypes(include=["object", "category"]).columns.tolist(), key="box_cat")
        num_col = st.selectbox("Variable numérique (Y)", df.select_dtypes(include=["number"]).columns.tolist(), key="box_num")
        st.plotly_chart(px.box(df, x=cat_col, y=num_col, title=f"Boxplot de {num_col} par {cat_col}"), use_container_width=True)

    with st.expander("🧮 Scatter Plot interactif", expanded=False):
        st.info("Affiche un nuage de points pour visualiser la relation entre deux variables numériques.")
        x_scatter = st.selectbox("Variable X", df.select_dtypes(include=["number"]).columns.tolist(), key="xscatter")
        y_scatter = st.selectbox("Variable Y", df.select_dtypes(include=["number"]).columns.tolist(), key="yscatter")
        color_scatter = st.selectbox("Couleur (catégorielle)", [None] + df.select_dtypes(include=["object", "category"]).columns.tolist(), key="color_scatter")
        fig = px.scatter(df, x=x_scatter, y=y_scatter, color=color_scatter, title="Scatter Plot interactif")
        st.plotly_chart(fig, use_container_width=True)

    with st.expander("🔀 Graphique croisé (moyenne d'une cible)", expanded=False):
        st.info("Permet de visualiser la moyenne d'une variable cible groupée par deux catégories.")
        cat1 = st.selectbox("Variable catégorielle 1 (X)", df.select_dtypes(include=["object", "category"]).columns.tolist(), key="group1")
        cat2 = st.selectbox("Variable catégorielle 2 (couleur)", df.select_dtypes(include=["object", "category"]).columns.tolist(), key="group2")
        agg_df = df.groupby([cat1, cat2])[target_1].mean().reset_index()
        fig2d = px.bar(agg_df, x=cat1, y=target_1, color=cat2, barmode="group", title=f"{target_1} moyen par {cat1} et {cat2}")
        st.plotly_chart(fig2d, use_container_width=True)


# === 4. EXPORT FINAL ===
    with st.expander("📄 Générer un rapport HTML automatisé", expanded=False):
        st.info("Crée un rapport EDA complet en HTML (via pandas profiling).")
        if st.button("Générer le rapport"):
            from ydata_profiling import ProfileReport
            profile = ProfileReport(df, title="Rapport EDA automatique", explorative=True)
            profile.to_file("data/exports/eda_report.html")
            with open("data/exports/eda_report.html", "rb") as f:
                st.download_button("Télécharger le rapport HTML", f, file_name="eda_report.html")

    with st.expander("💾 Sauvegarder le DataFrame final avec log", expanded=False):
        st.info("Enregistre le DataFrame nettoyé et documente les actions effectuées dans un fichier log.")
        if st.button("Sauvegarder maintenant"):
            from streamlit_app.log_utils import log_transformation
            path = "data/exports/final_dataframe.parquet"
            df.to_parquet(path)
            log_transformation(f"DataFrame sauvegardé à {path} avec {df.shape[0]} lignes et {df.shape[1]} colonnes.")
            st.success("Fichier sauvegardé et log mis à jour.")

    st.header("4. Export du fichier nettoyé")
    st.markdown("Téléchargez la version actuelle du DataFrame transformé.")
    if st.button("Exporter"):
        r = requests.get(f"{API_URL}/export/")
        if r.status_code == 200:
            st.download_button("Télécharger le CSV", r.content, file_name="cleaned_data.csv")
