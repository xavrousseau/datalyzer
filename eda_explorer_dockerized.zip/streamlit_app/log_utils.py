
from loguru import logger
from pathlib import Path

LOG_PATH = Path("logs/eda_transformations.log")
LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
logger.add(str(LOG_PATH), format="{time} | {level} | {message}", level="INFO")

def log_transformation(message: str):
    logger.info(message)
