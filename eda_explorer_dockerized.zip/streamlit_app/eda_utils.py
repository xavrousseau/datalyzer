import pandas as pd
import numpy as np
from sklearn.preprocessing import OneHotEncoder, OrdinalEncoder
from scipy import stats

def detect_variable_types(df: pd.DataFrame) -> pd.DataFrame:
    """Détecte les types logiques de chaque colonne du DataFrame.

    Retourne un DataFrame avec : colonne, type logique (numérique, catégorielle...), dtype réel, nb de valeurs uniques.
    """
    types = []
    for col in df.columns:
        unique_vals = df[col].nunique()
        dtype = df[col].dtype
        if pd.api.types.is_numeric_dtype(df[col]):
            if unique_vals == 2:
                var_type = "binaire"
            else:
                var_type = "numérique"
        elif unique_vals < 20:
            var_type = "catégorielle"
        else:
            var_type = "texte libre"
        types.append({"colonne": col, "type": var_type, "dtype": str(dtype), "valeurs_uniques": unique_vals})
    return pd.DataFrame(types)

def compute_correlation_matrix(df: pd.DataFrame) -> pd.DataFrame:
    """Calcule la matrice de corrélation entre variables numériques."""
    numeric_df = df.select_dtypes(include=[np.number])
    return numeric_df.corr()

def detect_outliers_iqr(df: pd.DataFrame, column: str) -> pd.DataFrame:
    """Retourne les outliers d'une colonne numérique selon la méthode IQR."""
    Q1 = df[column].quantile(0.25)
    Q3 = df[column].quantile(0.75)
    IQR = Q3 - Q1
    lower = Q1 - 1.5 * IQR
    upper = Q3 + 1.5 * IQR
    return df[(df[column] < lower) | (df[column] > upper)]

def detect_constant_columns(df: pd.DataFrame) -> list:
    """Retourne la liste des colonnes constantes (une seule valeur)."""
    return [col for col in df.columns if df[col].nunique() == 1]

def detect_low_variance_columns(df: pd.DataFrame, threshold: float = 0.01) -> list:
    """Retourne les colonnes numériques ayant une faible variance (< seuil)."""
    num_df = df.select_dtypes(include=[np.number])
    variances = num_df.var()
    return variances[variances < threshold].index.tolist()

def encode_categorical(df: pd.DataFrame, method: str = "onehot", columns: list = None) -> pd.DataFrame:
    """Encode les colonnes catégorielles avec la méthode choisie (onehot ou ordinal).

    Args:
        df: DataFrame d'entrée
        method: 'onehot' ou 'ordinal'
        columns: liste des colonnes à encoder (détectées automatiquement si None)

    Returns:
        DataFrame avec les colonnes encodées
    """
    if columns is None:
        columns = df.select_dtypes(include=["object", "category"]).columns.tolist()

    if method == "onehot":
        return pd.get_dummies(df, columns=columns)
    elif method == "ordinal":
        encoder = OrdinalEncoder()
        df[columns] = encoder.fit_transform(df[columns])
        return df
    else:
        raise ValueError("Méthode d'encodage inconnue : choisir 'onehot' ou 'ordinal'")
