from fastapi import FastAPI, UploadFile, File
from fastapi.responses import JSONResponse, FileResponse
from pydantic import BaseModel
from typing import List
import pandas as pd
import os
import io

app = FastAPI(title="EDA Backend API")

UPLOAD_DIR = "data/uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)
DATA_STORE = {}

class ColumnDropRequest(BaseModel):
    columns: List[str]

@app.post("/upload/")
async def upload_csv(file: UploadFile = File(...)):
    try:
        contents = await file.read()
        df = pd.read_csv(io.BytesIO(contents))
        DATA_STORE["df"] = df
        return {"filename": file.filename, "columns": df.columns.tolist(), "rows": len(df)}
    except Exception as e:
        return JSONResponse(status_code=400, content={"error": str(e)})

@app.get("/head/")
def get_head(n: int = 5):
    df = DATA_STORE.get("df")
    if df is None:
        return JSONResponse(status_code=404, content={"error": "Aucun fichier chargé."})
    return df.head(n).to_dict(orient="records")

@app.get("/missing-values/")
def get_missing_values():
    df = DATA_STORE.get("df")
    if df is None:
        return JSONResponse(status_code=404, content={"error": "Aucun fichier chargé."})
    missing = df.isnull().sum()
    percent = (missing / len(df)) * 100
    result = pd.DataFrame({"column": missing.index, "missing_count": missing.values, "missing_percent": percent.values})
    return result[result["missing_count"] > 0].to_dict(orient="records")

@app.get("/describe/")
def get_description():
    df = DATA_STORE.get("df")
    if df is None:
        return JSONResponse(status_code=404, content={"error": "Aucun fichier chargé."})
    return df.describe(include="all").fillna("").to_dict()

@app.get("/duplicates/")
def get_duplicates():
    df = DATA_STORE.get("df")
    if df is None:
        return JSONResponse(status_code=404, content={"error": "Aucun fichier chargé."})
    dup = df[df.duplicated()]
    return {"duplicate_rows": len(dup), "percentage": round(100 * len(dup) / len(df), 2)}

@app.post("/drop-duplicates/")
def drop_duplicates():
    df = DATA_STORE.get("df")
    if df is None:
        return JSONResponse(status_code=404, content={"error": "Aucun fichier chargé."})
    before = len(df)
    df_cleaned = df.drop_duplicates()
    DATA_STORE["df"] = df_cleaned
    after = len(df_cleaned)
    return {"removed": before - after, "remaining_rows": after}

@app.post("/drop-columns/")
def drop_columns(request: ColumnDropRequest):
    df = DATA_STORE.get("df")
    if df is None:
        return JSONResponse(status_code=404, content={"error": "Aucun fichier chargé."})
    missing = [col for col in request.columns if col not in df.columns]
    if missing:
        return JSONResponse(status_code=400, content={"error": f"Colonnes introuvables : {missing}"})
    df.drop(columns=request.columns, inplace=True)
    DATA_STORE["df"] = df
    return {"message": f"{len(request.columns)} colonnes supprimées avec succès."}

@app.get("/export/")
def export_csv():
    df = DATA_STORE.get("df")
    if df is None:
        return JSONResponse(status_code=404, content={"error": "Aucun fichier chargé."})
    path = os.path.join(UPLOAD_DIR, "data_cleaned.csv")
    df.to_csv(path, index=False)
    return FileResponse(path, media_type="text/csv", filename="data_cleaned.csv")

@app.get("/report/")
def generate_report():
    df = DATA_STORE.get("df")
    if df is None:
        return JSONResponse(status_code=404, content={"error": "Aucun fichier chargé."})
    path = os.path.join(UPLOAD_DIR, "eda_report.csv")
    df.describe(include="all").transpose().to_csv(path)
    return FileResponse(path, media_type="text/csv", filename="eda_report.csv")
